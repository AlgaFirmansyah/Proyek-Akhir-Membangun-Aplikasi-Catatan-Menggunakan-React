import React from 'react';
import NoteItem from './NoteItem';

function groupNotesByMonth(notes) {
  const groups = new Map();

  notes.forEach((note) => {
    const label = new Date(note.createdAt).toLocaleDateString('id-ID', {
      month: 'long',
      year: 'numeric',
    });

    if (!groups.has(label)) {
      groups.set(label, []);
    }
    groups.get(label).push(note);
  });

  return Array.from(groups.entries());
}

function NotesList({
  notes,
  onDelete,
  onArchive,
  searchKeyword = '',
  dataTestId = 'notes-list',
}) {
  // TODO [Basic] validasi notes agar tidak kosong.
  const hasNotes = Array.isArray(notes) && notes.length > 0;

  if (!hasNotes) {
    return (
      <div className="notes-list" data-testid={dataTestId}>
        {/* TODO [Basic] tampilkan pesan kosong yang informatif ketika tidak ada catatan. */}
        <p
          className="notes-list__empty-message"
          data-testid={`${dataTestId}-empty`}
        >
          Tidak ada catatan
        </p>
      </div>
    );
  }

  return (
    <div className="notes-list" data-testid={dataTestId}>
      {/* TODO [Basic] gunakan array.map untuk merender NoteItem untuk setiap catatan. */}
      {/* TODO [Skilled] ekstrak tombol aksi menjadi komponen reusable agar dipakai NoteItem. */}
      {/* TODO [Advanced] kelompokkan catatan per bulan-tahun dan render tiap grup dalam <section className="notes-group">. */}
      {groupNotesByMonth(notes).map(([label, groupNotes]) => (
        <section className="notes-group" key={label}>
          <h3 className="notes-group__title">{label}</h3>
          <p className="notes-group__count">{groupNotes.length} catatan</p>
          {groupNotes.map((note) => (
            <NoteItem
              key={note.id}
              note={note}
              onDelete={onDelete}
              onArchive={onArchive}
              searchKeyword={searchKeyword}
            />
          ))}
        </section>
      ))}
    </div>
  );
}

export default NotesList;