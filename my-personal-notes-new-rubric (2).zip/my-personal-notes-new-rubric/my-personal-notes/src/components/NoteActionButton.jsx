import React from 'react';

const DEFAULT_LABELS = {
  delete: 'Delete',
  archive: 'Arsipkan',
};

function NoteActionButton({ variant, onClick, children }) {
  return (
    <button
      className={`note-item__${variant}-button`}
      type="button"
      onClick={onClick}
      data-testid={`note-item-${variant}-button`}
    >
      {children ?? DEFAULT_LABELS[variant]}
    </button>
  );
}

export default NoteActionButton;